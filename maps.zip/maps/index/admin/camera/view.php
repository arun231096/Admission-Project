<?php 
  $con = mysqli_connect("localhost", "root", "","webcam");
  $sql = "SELECT *from entry";
  $result = mysqli_query($con,$sql);
  while($row = mysqli_fetch_assoc($result)){
  echo $row[id];
echo "<br>";
header("Content-type:images/jpeg");
  echo mysql_result($result,1);
}
?>


