<?php
$host="localhost";
$user="######";
$password="####";
$databasename="#####";

$con=  mysqli_connect($host,$user,$password,$databasename);




?>
