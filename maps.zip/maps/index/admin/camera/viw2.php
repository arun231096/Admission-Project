<?php 

//error_reporting(0);
    ob_start();
session_start();
echo "<head><title>MAPS</title></head>";
$id=$_SESSION["apno"];
$conn = @mysqli_connect("localhost","#####","#####","#####");
//mysql_select_db("maps") or die(mysql_error());

$sql = "select *from student where apno=$id";
$sql1="select *from sparent where apno=$id";
$result = @mysqli_query($conn,$sql) or die("<b>Error:</b> Problem on Retrieving Image BLOB<br/>" . mysql_error());

$row = @mysqli_fetch_array($result);

$sname=$row["sname"];
$lang=$row["slang"];
$ay=$row["ayear"];
$class=$row["coa"];
$sphoto=$row["sphoto"];
//$sphoto="http://mapschool.co.in/index/admin/camera/".$sphoto;
$d=$row["date"];
$result1 = @mysqli_query($conn,$sql1) or die("<b>Error:</b> Problem on Retrieving Image BLOB<br/>" . mysql_error());
$row = @mysqli_fetch_array($result1);

$fname=$row["fname"];
$mname=$row["mname"];
$fphoto=$row["fphoto"];
//$fphoto="http://mapschool.co.in/index/admin/camera/".$fphoto;
$mphoto=$row["mphoto"];
$num=$row["fmno"];
$sign=$row["sign"];
//$sign="http://mapschool.co.in/index/admin/camera/".$sign;
$femail=$row["femail"];
$email="mapsprincipal@sasurie.com";
$contact="9488891111 <br> 9442593824";
//echo "$ph";
//$ph=$ph.".jpg";
//echo "<img src='$ph' width='200' height='200'>";
$path="http//:www.mapschool.co.in/index/admin/camera";

$body = "<table width=\"400\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">
				  <tr>
					<td bgcolor=\"#FFFFFF\"><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"#e3e3e3\">
					  <tr>
						<td bgcolor=\"#FFFFFF\"><div align=\"center\"><font color=\"#FF0000\" size=\"3\"><b>Acknowledgement</b></font></div></td>
					  </tr>
					</table>
					  <table width=\"100%\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\">
					   
					   <tr> 
				<td>
				<center><img src='http://mapschool.co.in/index/admin/img/MAPSLogo.jpg' width='150' height='150'></td>
				
					<td><img src='http://mapschool.co.in/index/admin/img/MAPSName.jpg' width='440' height='100'></td></center>
				</td> </tr>
					   
					   
						<tr>
						  <td bgcolor=\"#FFFFFF\"><font color=\"#5e686e\" size=\"2\"><b>Application.No:- ".$id."</b></font></td>
						  <td bgcolor=\"#FFFFFF\"> Acadamic year:- ".$ay."</td>
						    <td bgcolor=\"#FFFFFF\">Second Language:- ".$lang."</td>
						</tr>

                                                <tr>
						  <td bgcolor=\"#FFFFFF\"><font color=\"#5e686e\" size=\"2\"><b> Name:-:- ".$sname."</b></font></td>
						  <td bgcolor=\"#FFFFFF\">Class:- ".$class."</td>
						  <td><img src='$sphoto' width='50' height='50'></td>
						</tr>
												<tr>
						  <td bgcolor=\"#FFFFFF\"><font color=\"#5e686e\" size=\"2\"><b>Father Name:- ".$fname."</b></font></td>
						  <td bgcolor=\"#FFFFFF\">Number:- ".$num." </td>
						  <td bgcolor=\"#FFFFFF\"><img src='$fphoto' width='50' height='50'> </td>
						</tr>
						<tr>
						  <td bgcolor=\"#FFFFFF\"><font color=\"#5e686e\" size=\"2\"><b>Email:- ".$email."</b></font></td>
						  <td bgcolor=\"#FFFFFF\">For contact:- ".$contact."</td>
						   <td><b>Signature </b><img src='$sign' width='50' height='50'></td>
						</tr>		
						
						<tr>
						  <td bgcolor=\"#FFFFFF\" align='center'>Admission Date<br>".$d."</td>
						  <td align='center'><font size=\"4\"><b>Thank you for choosing <br>MALAR ACE PUBLIC SCHOOL</b></font></td>
						</tr>


						</table></td>
				  </tr>
				</table>";
				
				echo"<center>$body</center>";
			
				
				
				
									
				$to = "$femail";
				$from = "info@#####.co.in";
				$subject = "ADMISSION DETAIL OF YOUR SON/DAUGHTER FROM MALAR ACE PUBLIC SCHOOL ";
				$message = $body;
				$headers  = "From: $from\r\n";
				$headers .= "Content-type: text/html\r\n";
				$mail=mail($to, $subject, $message, $headers);
                
                
                echo("<center>Thank you for Admission</center>");
                echo "<br><br><b>Designed by Sasurie Info Tech</b>";
                $C="Application.No:-$id, Name:- $sname, class:- $class, Father Name:- $fname, Email:-mapsprincipal@sasurie.com For Contact:- 9488891111  Thank you for choosing MAPS";
				$_SESSION["apno"]=" ";
				echo "<br><center><a href='../maps.php'><button type='button'>Main</button></center></a>";
				sendWay2SMS('#####','#####',$num,$C);
function sendWay2SMS($uid, $pwd, $phone, $msg)
{
  echo "<center><script>window.alert('Your messege send');</script></center>";
  $curl = curl_init();
  $timeout = 30;
  $result = array();
  $uid = urlencode($uid);
  $pwd = urlencode($pwd);
  //$autobalancer = rand(1, 8);
  $autobalancer = 23;
  // Setup for login
  curl_setopt($curl, CURLOPT_URL, "http://site".$autobalancer.".way2sms.com/Login1.action");
  curl_setopt($curl, CURLOPT_POST, 1);
  curl_setopt($curl, CURLOPT_POSTFIELDS, "username=".$uid."&password=".$pwd."&button=Login");
  curl_setopt($curl, CURLOPT_COOKIESESSION, 1);
  curl_setopt($curl, CURLOPT_COOKIEFILE, "cookie_way2sms");
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($curl, CURLOPT_MAXREDIRS, 20);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.0.5) Gecko/2008120122 Firefox/3.0.5");
  curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, $timeout);
  curl_setopt($curl, CURLOPT_REFERER, "http://site".$autobalancer.".way2sms.com/");
  $text = curl_exec($curl);
  // Check if any error occured
  if (curl_errno($curl))
    return "access error : ". curl_error($curl);
  // Check for proper login
  $pos = stripos(curl_getinfo($curl, CURLINFO_EFFECTIVE_URL), "ebrdg.action");
  if ($pos === "FALSE" || $pos == 0 || $pos == "")
    return "invalid login";
  // Check the message
  if (trim($msg) == "" || strlen($msg) == 0)
    return "invalid message";
  // Take only the first 140 characters of the message
  $msg = urlencode(substr($msg, 0, 140));
  // Store the numbers from the string to an array
  $pharr = explode(",", $phone);
  // Set the home page from where we can send message
  $refurl = curl_getinfo($curl, CURLINFO_EFFECTIVE_URL);
  $newurl = str_replace("ebrdg.action?id=", "main.action?section=s&Token=", $refurl);
  curl_setopt($curl, CURLOPT_URL, $newurl);
  // Extract the token from the URL
  $jstoken = substr($newurl, 50, -41);
  //Go to the homepage
  $text = curl_exec($curl);
  // Send SMS to each number
  foreach ($pharr as $p)
  {
    // Check the mobile number
    if (strlen($p) != 10 || !is_numeric($p) || strpos($p, ".") != false)
    {
      $result[] = array('phone' => $p, 'msg' => urldecode($msg), 'result' => "invalid number");
      continue;
    }
    $p = urlencode($p);
    // Setup to send SMS
    curl_setopt($curl, CURLOPT_URL, 'http://site'.$autobalancer.'.way2sms.com/smstoss.action');
    curl_setopt($curl, CURLOPT_REFERER, curl_getinfo($curl, CURLINFO_EFFECTIVE_URL));
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, "ssaction=ss&Token=".$jstoken."&mobile=".$p."&message=".$msg."&button=Login");
    $contents = curl_exec($curl);
    //Check Message Status
    $pos = strpos($contents, 'Message has been submitted successfully');
    $res = ($pos !== false) ? true : false;
    $result[] = array('phone' => $p, 'msg' => urldecode($msg), 'result' => $res);
  }
  // Logout
  curl_setopt($curl, CURLOPT_URL, "http://site".$autobalancer.".way2sms.com/LogOut");
  curl_setopt($curl, CURLOPT_REFERER, $refurl);
  $text = curl_exec($curl);
  curl_close($curl);
  return $result;
  
}





//mysql_close($conn);
?> 