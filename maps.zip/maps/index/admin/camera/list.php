<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="../css/style.css">
<link rel="shortcut icon" href="../img/MAPSLogo.jpg">
<style>
#ays{
	background-color:white;
	color:green;
	border-radius:10px;
}


</style>
<title>LIST</title>
</head>

<?php 

if(!isset($_SESSION)){
    error_reporting(0);
     ob_start();
    session_start();
    
}
$s=$_SESSION["pass"];
//echo "$s";
if(!empty($_SESSION["apno"])){ 

$id=$_SESSION["apno"];
//echo $id;
$conn = @mysqli_connect("localhost","#####","#####","#####");
$sql = "select *from student where apno=$id";
$sql1="select *from sparent where apno=$id";
$sql2="select *from stlang where apno=$id";
$result = @mysqli_query($conn,$sql) or die("<b>Error:</b> Problem on Retrieving<br/>" . mysql_error());
$row = @mysqli_fetch_array($result);

$id=$row["apno"];
$date=$row["date"];
$ay=$row["ayear"];
	$rno=$row["rc"];
    $name = $row["sname"];
	$dob=$row["dob"];
	$rlg=$row["reli"];
    $class=$row["coa"];
	$sphoto=$row["sphoto"];
	
    $sl=$row["slang"];
      $Gender=$row["gen"];
	  $num=$row["num"];
    $nat=$row["nat"];
    $mt=$row["mtoung"];
    $Caste=$row["caste"];
    $Resadd=$row["radd"];
    $mailadd=$row["madd"];
	if(!empty($row["pass"]))
	$pass=$row["pass"];
	else
	$pass="nil";



$result1 = @mysqli_query($conn,$sql1) or die("<b>Error:</b> Problem on Retrieving Image BLOB<br/>" . mysql_error());
$row = @mysqli_fetch_array($result1);


$fphoto=$row["fphoto"];

//$fphoto="http://mapschool.co.in/index/admin/camera/".$fphoto;
$mphoto=$row["mphoto"];

//$mphoto="http://mapschool.co.in/index/admin/camera/".$mphoto;
$sign=$row["sign"];

//$sign="http://mapschool.co.in/index/admin/camera/".$sign;


$fname=$row["fname"];
      $mname=$row["mname"];
	  if(!empty($row["gname"]))
      $gname=$row["gname"];
	  
      $fexd=$row["fquali"];
      $mexd=$row["mquali"];
	   
	   if(!empty($row["gquali"]))
      $gexd=$row["gquali"];
	  else $gexd="nil";
	  
      $foccup=$row["focc"];
	  $moccup=$row["mocc"];
	  
	   if(!empty($row["gocc"]))
	  $goccup=$row["gocc"];
	  else 
	  $goccup="nil";
	  
	  $fincome=$row["finc"];
	  
	  if(!empty($row["ginc"]))
	  $gincome=$row["ginc"];
	  else 
	  $gincome="nil";
	  
	   if(!empty($row["minc"]))
	  $mincome=$row["minc"];
	  
	  $fmob=$row["fmno"];
	  $mmob=$row["mmno"];
	  
	  if(!empty($row["gmno"]))
	  $gmob=$row["gmno"];
	  else 
	  $gmob="nil";
	  
	  $femail=$row["femail"];
	  if(!empty($row["memail"]))
	  $memail=$row["memail"];
	  else 
	  $memail="nil";
	  
	   if(!empty($row["gemail"]))
	  $gemail=$row["gemail"];
	  else
	  $gemail="nil";
	  
	  $fadd=$row["foffadd"];
	   if(!empty($row["goffadd"]))
	  $gadd=$row["goffadd"];
	  else 
	  $gadd="nil";
	  $madd=$row["moffadd"];
	  $sign=$row["sign"];
	  if(!empty($row["whatsapp"]))
	  $wapp=$row["whatsapp"];
	  else
	  $wapp="nil";

$result = @mysqli_query($conn,$sql2) or die("<b>Error:</b> Problem on Retrieving Content<br/>" . mysql_error());
$row = @mysqli_fetch_array($result);


if(!empty($row["lk1"])){
    $lang1=$row["lk1"];
	 $re1=$row["r1"];
	  $sp1=$row["s1"];
	   $w1=$row["w1"];
	   }
	   if(!empty($row["lk2"])){
    $lang2=$row["lk2"];
	  $sp2=$row["s2"];
	 $re2=$row["r2"];
	    $w2=$row["w2"];
	 }
	 if(!empty($row["lk3"])){
    $lang3=$row["lk3"];
	 $sp3=$row["s3"];
	   $re3=$row["r3"]; 
	   $w3=$row["w3"];
	   
	   }
	   if(!empty($row["lk4"])){
    $lang4=$row["lk4"];
	  $sp4=$row["s4"];
	   $re4=$row["r4"];
	    $w4=$row["w4"];
	   
	   }
	   if(!empty($row["lk5"])){
    $lang5=$row["lk5"]; 
    $sp5=$row["s5"];   
    $re5=$row["r5"];
	 $w5=$row["w5"];
	}
   
 if(!empty($row["medi1"])) 
      $aoh1=$row["medi1"];
	  
	   if(!empty($row["medi2"]))
      $aoh2=$row["medi2"];
	  
	   if(!empty($row["medi3"]))
      $aoh3=$row["medi3"];
}
?>

<body bgcolor="solidGreen"> <center>
	<div align="center" id="page">
	<form action="../Index.php" method="post" enctype="multipart/form-data">
		<div align="center" id="main">
			<center>

<font size="2">

			<table id="innner" border="0">
				<tr> 
				<td>
				<center><img src="../img/MAPSLogo.jpg" width="150" height="150"></center>
				
					<img src="../img/MAPSName.jpg" width="440" height="100"></td>
				</td> </tr>

				<tr><td id="apn"><center><b><font size="5">Details Form</font></b></center></td></tr>
			</table>


<br>
			<table align="center" id="sd" border="0">
				<tr><td><br>
					<table id="acc" border="0"><tr><td>Acadamic Year:-</td><td id="ays"><b><?php echo "$ay"; ?></b></td></tr>
					<tr><td align="left" id="na"><b>R.No:- </b><?php echo"$rno";?></td>
					<td>Class for which <br>admission is sought:-</td>
					<td> <?php echo"$class"; ?></td></tr>
					<tr><td><table> <tr> <td>Date of Issue:-</td><td id="ays"> <?php echo "<b>".$date; echo "</b>"; ?></td></tr></table></td>
					<td>Second Language:-</td>
					<td><?php echo "$sl";?></td></tr>
					</table>
				</td>
				</tr>
				
				</table>

				<br><b><table id="studd" border="0">
					<tr>
						<td align="left" id="na"><b>Name of the Student:- </b><?php echo strtoupper($name);?></td>
						<td align="left" id="na"><b>Student's Passport Number:- </b><?php echo strtoupper($pass);?></td>
					</tr>
					<tr>
						<td><br><font size="4">Gender:-<?php echo strtoupper($Gender);?></font></td>
						<td><font size="4">Date of Birth:- <?php echo "$dob";?></font></td>
					</tr></table>
					<br><table id="nat">
					<tr>
						<td>Nationality <br><?php echo strtoupper($nat);?></td>
						<td>Religion <br> <?php echo strtoupper($rlg);?></td>
						<td>Mother Tongue:-<br>
							<?php echo strtoupper($mt);?>
						</td>
						<td>Community:-<br>
							<?php echo strtoupper($Caste);?>
						</td>
						
					</tr>
				</table>


				<br><table id="add" border="0">
					<tr>
						<td>Residential Address<br><textarea id="t3" name="res_add" rows="10" cols="40" value=""><?php echo strtoupper($Resadd);?></textarea></td>
						<td>Mailing Address<br><textarea id="t4" name="mail_add" rows="10" cols="40" ><?php echo strtoupper($mailadd);?></textarea></td>
					</tr></table>
					<table>
					<tr>
						<td><table border="0" id="lang">
							<tr>
								<td id="lk"><center>Languages Known</center></td>
							</tr>
							<tr>
							<th>Language</th> <th> Speak </th> <th>Read </th> <th>Write</th>
							</tr>
							<tr>
								<td><?php echo strtoupper($lang1);?></td> <td>
								<?php echo strtoupper($sp1);?>
								</td><td> 
									<?php echo strtoupper($re1);?>
								 </td><td>
								 <?php echo strtoupper($w1);?>
								</td></tr><tr>
								<td><?php echo strtoupper($lang2);?></td><td> 
								<?php echo strtoupper($sp2);?></td><td> 
								<?php echo strtoupper($re2);?></td><td> 
								<?php echo strtoupper($w2);?></td></tr><br><tr>
								<td><?php echo strtoupper($lang3);?></td><td> 
								<?php echo strtoupper($sp3);?></td><td> <?php echo strtoupper($re3);?></td>
								<td><?php echo strtoupper($w3);?></td></tr><br><tr>
								<td><?php echo strtoupper($lang4);?></td><td> 
								<?php echo strtoupper($sp4);?></td><td> 
								<?php echo strtoupper($re4);?></td><td> 
								<?php echo strtoupper($w4);?></td></tr><br><tr>
								<td><?php echo strtoupper($lang5);?></td><td>
								<?php echo strtoupper($sp5);?></td><td> 
								<?php echo strtoupper($re5);?></td><td><?php echo strtoupper($w5);?></td>
							</tr>
						</table></td>
						<td>
						<br><table id="htc">
							<tr>
								<th>Has the Student been vaccinated regularly? Any other health concerns, allergies that the school to be aware of</th>
								<tr><td><br><?php echo strtoupper($aoh1);?></td></tr>
								<tr><td><br><?php echo strtoupper($aoh2);?></td></tr>
								<tr><td><br><?php echo strtoupper($aoh3);?></td></tr>
							</tr>
						</table></td>
					</tr>
				</table>

			</center>
		</div>
	
		<div align="center" id="main">
			<center>
			<b><br><font size="5">Parent's / Guardian's Information</font></b>
			<table id="innner" border="0">
				<tr><td>
					<table id="ptns" border="0">
						<tr>
							<th>Details</th>
							<th>Father</th>
							<th>Mother</th>
							<th>Guardian</th>
						</tr>
						<tr>
							<td id="d1">Name</td>
							<td><input type="text" id="t13" name="fname" value="<?php echo strtoupper($fname);?>"></td>
								<td><input type="text" id="t14" name="mname" value="<?php echo strtoupper($mname);?>"></td>
								<td><input type="text" id="t15" name="gname" value="<?php echo strtoupper($gname);?>"></td>
							</tr>
							<tr>
								<td id="d2">Educational Qualification</td>
								<td><input type="text" id="t16" name="fexd" value="<?php echo strtoupper($fexd);?>"></td>
								<td><input type="text" id="t17" name="mexd" value="<?php echo strtoupper($mexd);?>"></td>
								<td><input type="text" id="t18" name="gexd" value="<?php echo strtoupper($gexd);?>"></td>
							</tr>
							<tr><td id="d3">Occupation</td>
							<td><input type="text" id="t19" name="foccup" value="<?php echo strtoupper($foccup);?>"></td>
							<td><input type="text" id="t20" name="moccup" value="<?php echo strtoupper($moccup);?>"></td>
							<td><input type="text" id="t21" name="goccup" value="<?php echo strtoupper($goccup);?> "></td>
							</tr>
							<tr><td id="d4">Annual Income</td>
							<td><input type="text" id="t22" name="fincome" value="<?php echo strtoupper($fincome);?>"></td>
							<td><input type="text" id="t23" name="mincome" value="<?php echo strtoupper($mincome);?>"></td>
							<td><input type="text" id="t24" name="gincome" value="<?php echo strtoupper($gincome);?> "></td>
							</tr>
							<tr><td id="d5">Contact No.</td>
							<td><input type="text" id="t25" name="fmob" value="<?php echo strtoupper($fmob);?>"></td>
							<td><input type="text" id="t26" name="mmob" value="<?php echo strtoupper($mmob);?>"></td>
							<td><input type="text" id="t27" name="gmob" value="<?php echo strtoupper($gmob);?>"></td>
							</tr>
							<tr><td id="d6">E-mail</td>
							<td><input type="text" id="t28" name="femail" value="<?php echo $femail;?>"></td>
							<td><input type="text" id="t29" name="memail" value="<?php echo $memail;?> "></td>
							<td><input type="text" id="t30" name="gemail" value="<?php echo $gemail;?>"></td>
							</tr>
							<tr><td id="d7">Address of Employment/<br>Business & Office Contact Nos.</td>
							<td><textarea id="t31" name="fadd" rows="10" cols="25" value=" "><?php echo strtoupper($fadd);?></textarea></td>
							<td><textarea id="t32" name="madd" rows="10" cols="25" value=" "><?php echo strtoupper($madd);?></textarea></td>
							<td><textarea id="t33" name="gadd" rows="10" cols="25" value=" "><?php echo strtoupper($gadd);?></textarea></td>
							</tr>
							<tr>
							<td align="right"><img src="../img/whatsapp.png" width="40" height="40"></td>
							<td><input type="text" id="t28" name="wapp" value="<?php echo strtoupper($wapp);?>"></td>
						</tr>
					</table><br><br>
					<b>Upload Images</b>
					<table id="img">
					<br><tr><td> <img src="<?php echo $sphoto?>" width="120" height="120" /><br>
				Student</td>
				<td>  <img src="<?php echo $fphoto?>" width="120" height="120" /><br>
				Father</td>
				<td> <img src="<?php echo $mphoto?>" width="120" height="120" /><br>
				Mother</td>
				</tr>
				</table>
					<?php $_SESSION["apno"]=" ";?>
				</td>
				</tr>
				<tr><td align="right"><img src="<?php echo $sign?>" width="120" height="120" /><br>
				sign</td></tr>
							</table>
							<br><br><b><input type="submit" value="Logout" id="sub"><br><br>
							
							</b>
							
						</font>
			</center>
</form></div>
<b>Designed by Sasurie Info Tech</b>
</body>
</html>
