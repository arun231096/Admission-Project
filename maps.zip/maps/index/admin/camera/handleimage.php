<?php

include 'connection.php';
include 'index.php';
$name = $_SESSION["apno"];
$r=$_SESSION["rc"];
mkdir("images/".$name);
$newname="images/".$name."/".$name."_".$r.".jpg";
$file = file_put_contents( $newname, file_get_contents('php://input') );
if (!$file) {
	print "Error occured here";
	exit();
}
else
{
if($r== "child"){
    $sql="update student set sphoto='$newname' where apno='$name'";

    $result=mysqli_query($con,$sql);
    $value=mysqli_insert_id($con);
   // $_SESSION["myvalue"]=$value;
   }
   else if($r=="father"){
   					$sql="update sparent set fphoto='$newname' where apno='$name'";

    $result=mysqli_query($con,$sql);
    $value=mysqli_insert_id($con);
   
   }
   else if($r== "mother"){
   $sql="update sparent set mphoto='$newname' where apno='$name'";

    $result=mysqli_query($con,$sql);
    $value=mysqli_insert_id($con);
	}
	}

$url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . '/' . $newname;
print "$url\n";

?>
