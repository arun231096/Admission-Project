<!Doctype html><head>
	<title>MAPS</title>

<link rel="stylesheet" type="text/css" href="../css/style.css">
<link rel="shortcut icon" href="../img/clg.jpg">
<style>
#ays{
	background-color:white;
	color:green;
	border-radius:10px;
}


</style>
</head>
<?php 

if(!isset($_SESSION)){
    error_reporting(0);
     ob_start();
    session_start();
    
}
$s=$_SESSION["pass"];
//echo "$s";
if($s=="#####"){ 

$id=$_SESSION["apno"];
$conn = @mysqli_connect("localhost","#####","#####","#####");
$sql = "select *from student where apno=$id";
$sql1="select *from sparent where apno=$id";
$sql2="select *from stlang where apno=$id";
$result = @mysqli_query($conn,$sql) or die("<b>Error:</b> Problem on Retrieving Image BLOB<br/>" . mysql_error());
$row = @mysqli_fetch_array($result);

$id=$row["apno"];
$date=$row["date"];
$ay=$row["ayear"];
	$rno=$row['rc'];
    $name = $row["sname"];
	$dob=$row["dob"];
	$rlg=$row["reli"];
    $class=$row["coa"];
	$sphoto=$row["sphoto"];
    $sl=$row["slang"];
      $Gender=$row["gen"];
	  $num=$row["num"];
    $nat=$row["nat"];
    $mt=$row["mtoung"];
    $Caste=$row["caste"];
    $Resadd=$row["radd"];
    $mailadd=$row["madd"];
	if(!empty($row["pass"]))
	$pass=$row["pass"];



$result1 = @mysqli_query($conn,$sql1) or die("<b>Error:</b> Problem on Retrieving Image BLOB<br/>" . mysql_error());
$row = @mysqli_fetch_array($result1);


$result1 = @mysqli_query($conn,$sql1) or die("<b>Error:</b> Problem on Retrieving Image BLOB<br/>" . mysql_error());
$row = @mysqli_fetch_array($result1);


$fphoto=$row["fphoto"];

//$fphoto="http://mapschool.co.in/index/admin/camera/".$fphoto;
$mphoto=$row["mphoto"];

//$mphoto="http://mapschool.co.in/index/admin/camera/".$mphoto;
$sign=$row["sign"];

//$sign="http://mapschool.co.in/index/admin/camera/".$sign;


$fname=$row["fname"];
      $mname=$row["mname"];
	  if(!empty($row["gname"]))
      $gname=$row["gname"];
	  
      $fexd=$row["fquali"];
      $mexd=$row["mquali"];
	   
	   if(!empty($row["gquali"]))
      $gexd=$row["gquali"];
	  else $gexd="nil";
	  
      $foccup=$row["focc"];
	  $moccup=$row["mocc"];
	  
	   if(!empty($row["gocc"]))
	  $goccup=$row["gocc"];
	  else 
	  $goccup="nil";
	  
	  $fincome=$row["finc"];
	  
	  if(!empty($row["ginc"]))
	  $gincome=$row["ginc"];
	  else 
	  $gincome="nil";
	  
	   if(!empty($row["minc"]))
	  $mincome=$row["minc"];
	  
	  $fmob=$row["fmno"];
	  $mmob=$row["mmno"];
	  
	  if(!empty($row["gmno"]))
	  $gmob=$row["gmno"];
	  else 
	  $gmob="nil";
	  
	  $femail=$row["femail"];
	  if(!empty($row["memail"]))
	  $memail=$row["memail"];
	  else 
	  $memail="";
	  
	   if(!empty($row["gemail"]))
	  $gemail=$row["gemail"];
	  else
	  $gemail="";
	  
	  $fadd=$row["foffadd"];
	   if(!empty($row["goffadd"]))
	  $gadd=$row["goffadd"];
	  else 
	  $gadd="nil";
	  $madd=$row["moffadd"];
	  if(!empty($row["whatsapp"]))
	  $wapp=$row["whatsapp"];
	  else
	  $wapp="nil";
	  $fphoto=$row["fphoto"];
	  $mphoto=$row["mphoto"];
	  $sign=$row["sign"];
$result = @mysqli_query($conn,$sql2) or die("<b>Error:</b> Problem on Retrieving Content<br/>" . mysql_error());
$row = @mysqli_fetch_array($result);


if(!empty($row["lk1"])){
    $lang1=$row["lk1"];
	 $re1=$row["r1"];
	  $sp1=$row["s1"];
	   $w1=$row["w1"];
	   }
	   if(!empty($row["lk2"])){
    $lang2=$row["lk2"];
	  $sp2=$row["s2"];
	 $re2=$row["r2"];
	    $w2=$row["w2"];
	 }
	 if(!empty($row["lk3"])){
    $lang3=$row["lk3"];
	 $sp3=$row["s3"];
	   $re3=$row["r3"]; 
	   $w3=$row["w3"];
	   
	   }
	   if(!empty($row["lk4"])){
    $lang4=$row["lk4"];
	  $sp4=$row["s4"];
	   $re4=$row["r4"];
	    $w4=$row["w4"];
	   
	   }
	   if(!empty($row["lk5"])){
    $lang5=$row["lk5"]; 
    $sp5=$row["s5"];   
    $re5=$row["r5"];
	 $w5=$row["w5"];
	}
   
 if(!empty($row["medi1"])) 
      $aoh1=$row["medi1"];
	  
	   if(!empty($row["medi2"]))
      $aoh2=$row["medi2"];
	  
	   if(!empty($row["medi3"]))
      $aoh3=$row["medi3"];




?>
<body bgcolor="solidGreen"><center>
	<div align="center" id="page">
	<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" enctype="multipart/form-data">
		<div align="center" id="main">
			<center>

<font size="2">

			<table id="innner" border="0">
				<tr> 
				<td>
				<center><img src="../img/MAPSLogo.jpg" width="150" height="150"></center>
				
					<img src="../img/MAPSName.jpg" width="440" height="100"></td>
				</td> </tr>

				<tr><td id="apn"><center><b><font size="5">Update Form</font></b></center></td></tr>
			</table>


<br>
			<table align="center" id="sd" border="0">
				<tr><td><br>
					<table id="acc" border="0"><tr><td>Acadamic Year:-<?php echo "$ay"; ?></td><td id="ays"><b>Application Num:- <?php echo "$id"; ?></b></td></tr>
					<tr><td align="left" id="na"><b>R.No:- </b><input type="text" id="t1" name="rc" value="<?php echo "$rno";?>"></td>
					<td>Class for which <br>admission is sought:-</td>
					<td> <select name="cls1" id="cls1">
					<option value="PreKG">PreKG</option>
					<option value="LKG">LKG</option>
					<option value="UKG">UKG</option>
							<option value="I">I</option>
							<option value="II">II</option>
							<option value="III">III</option>
							<option value="IV">IV</option>
							<option value="V">V</option>
							<option value="VI">VI</option>
						</select></td></tr>
					<tr><td><table> <tr> <td>Date of Issue:-</td><td id="ays"> <?php echo "<b>".$date; echo"</b>"; ?></td></tr></table></td>
					<td>Second Language:-</td>
					<td><input type="text" name="seclang" id="t36" Placeholder="Second Language" value="<?php echo $sl; ?>"required></td></tr>
					</table>
				</td>
				</tr>
				
				</table>

				<br><b><table id="studd" border="0">
					<tr>
						<td align="left" id="na"><b>Name of the Student:- </b><input type="text" id="t1" name="nos" value="<?php echo strtoupper($name);?>"></td>
						<td align="left" id="na"><b>Student's Passport Number:- </b><input type="text" id="t1" name="pass" value="<?php echo strtoupper($pass);?>"></td>
					</tr>
					<tr>
						<td><br><font size="4">Gender:-</font><input type="radio" name="gender" value="male" required>Male &nbsp;<input type="radio" name="gender" value="female" required>Female &nbsp;<input type="radio" name="gender" value="other" required>Other</td>
						<td><font size="4">Date of Birth:- </font><input type="date" name="dob" value="<?php echo $dob; ?>"></td>
					</tr></table>
					<br><table id="nat">
					<tr>
						<td>Nationality <br><input type="text" id="t2" name="ntl" value="<?php echo strtoupper($nat);?>" required></td>
						<td>Religion <br> <select name="rlg" id="s1">
							<option value="hindu">Hindu</option>
							<option value="Christian">Christian</option>
							<option value="muslim">Muslim</option>
							<option value="other">Other</option>
						</select></td>
						<td>Mother Tongue:-<br>
							<select name="mt" id="s2">
							<option value="tamil">Tamil</option>
							<option value="kannada">Kannada</option>
							<option value="telugu">Telugu</option>
							<option value="malayalam">Malayalam</option>
							<option value="hindi">Hindi</option>
							<option value="other">Other</option>
						</select>
						</td>
						<td>Community:-<br>
							<select name="caste" id="s3">
							<option value="mbc">MBC</option>
							<option value="bc">BC</option>
							<option value="sc">SC</option>
							<option value="other">Other</option>
						</select>
						</td>
						<td>Caste (for Satistics)<br><input type="text" id="t2" name="com" value="<?php echo strtoupper($Caste);?>"></td>
					</tr>
				</table>


				<br><table id="add" border="0">
					<tr>
						<td>Residential Address<br><textarea id="t3" name="res_add" rows="10" cols="40" Placeholder="Residential Address"><?php echo strtoupper($Resadd);?></textarea></td>
						<td>Mailing Address<br><textarea id="t4" name="mail_add" rows="10" cols="40" Placeholder="Mailling Address" required><?php echo strtoupper($mailadd);?></textarea></td>
					</tr></table>
					<table>
					<tr>
						<td><table border="0" id="lang">
							<tr>
								<td id="lk"><center>Languages Known</center></td>
							</tr>
							<tr>
							<th>Language</th> <th> Speak </th> <th>Read </th> <th>Write</th>
							</tr>
							<tr>
								<td><input type="text" id="t5" name="lk1" value="<?php echo strtoupper($lang1);?>" Placeholder="Language 1"></td> <td>
								<select name="speak1">
								<option value="nil">nil</option>				
								<option value="yes">Yes</option>				
								<option value="no">No</option>
								</select>
								</td><td> 
									<select name="read1">
									<option value="nil">nil</option>
								<option value="yes">Yes</option>				
								<option value="no">No</option>
								</select>
								 </td><td>
								 <select name="write1">
								 <option value="nil">nil</option>
								<option value="yes">Yes</option>				
								<option value="no">No</option>
								</select>
								</td></tr><tr>
								<td><input type="text" id="t6" name="lk2" value="<?php echo strtoupper($lang2);?> " Placeholder="Language 2"></td><td> 
								<select name="speak2">
								<option value="nil">nil</option>
								<option value="yes">Yes</option>				
								<option value="no">No</option>
								</select></td><td> 
								<select name="read2">
								<option value="nil">nil</option>
								<option value="yes">Yes</option>				
								<option value="no">No</option>
								</select></td><td> 
								<select name="write2">
								<option value="nil">nil</option>
								<option value="yes">Yes</option>				
								<option value="no">No</option>
								</select></td></tr><br><tr>
								<td><input type="text" id="t7" name="lk3" value="<?php echo strtoupper($lang3);?>" Placeholder="Language 3"></td><td> 
								<select name="speak3">
								<option value="nil">nil</option>
								<option value="yes">Yes</option>				
								<option value="no">No</option>
								</select></td><td> <select name="read3">
								<option value="nil">nil</option>
								<option value="yes">Yes</option>				
								<option value="no">No</option>
								</select></td><td><select name="write3">
								<option value="nil">nil</option>
								<option value="yes">Yes</option>				
								<option value="no">No</option>
								</select></td></tr><br><tr>
								<td><input type="text" id="t8" name="lk4" value="<?php echo strtoupper($lang4);?>" Placeholder="Language 4"></td><td> 
								<select name="speak4">
								<option value="nil">nil</option>
								<option value="yes">Yes</option>				
								<option value="no">No</option>
								</select></td><td> 
								<select name="read4">
								<option value="nil">nil</option>
								<option value="yes">Yes</option>				
								<option value="no">No</option>
								</select></td><td> 
								<select name="write4">
								<option value="nil">nil</option>
								<option value="yes">Yes</option>				
								<option value="no">No</option>
								</select></td></tr><br><tr>
								<td><input type="text" id="t9" name="lk5" value="<?php echo strtoupper($lang3);?>" Placeholder="Language 5"></td><td>
								<select name="speak5">
								<option value="nil">nil</option>
								<option value="yes">Yes</option>				
								<option value="no">No</option>
								</select></td><td> 
								<select name="read5">
								<option value="nil">nil</option>
								<option value="yes">Yes</option>				
								<option value="no">No</option>
								</select></td><td> <select name="write5">
								<option value="nil">nil</option>
								<option value="yes">Yes</option>				
								<option value="no">No</option>
								</select></td>
							</tr>
						</table></td>
						<td>
						<br><table id="htc">
							<tr>
								<th>Has the Student been vaccinated regularly? Any other health concerns, allergies that the school to be aware of</th>
								<tr><td><br><input type="text" id="t10" name="aohealthcare1" value="<?php echo strtoupper($aoh1);?>"></td></tr>
								<tr><td><br><input type="text" id="t11" name="aohealthcare2" value="<?php echo strtoupper($aoh2);?>"></td></tr>
								<tr><td><br><input type="text" id="t12" name="aohealthcare3" value="<?php echo strtoupper($aoh3);?>"></td></tr>
							</tr>
						</table></td>
					</tr>
				</table>

			</center>
		</div>
	
		<div align="center" id="main">
			<center>
			<b><br><font size="5">Parent's / Guardian's Information</font></b>
			<table id="innner" border="0">
				<tr><td>
					<table id="ptns" border="0">
						<tr>
							<th>Details</th>
							<th>Father</th>
							<th>Mother</th>
							<th>Guardian</th>
						</tr>
						<tr>
							<td id="d1">Name</td>
							<td><input type="text" id="t13" name="fname" value="<?php echo strtoupper($fname);?>" required></td>
								<td><input type="text" id="t14" name="mname" value="<?php echo strtoupper($mname);?>" required></td>
								<td><input type="text" id="t15" name="gname" value="<?php echo strtoupper($gname);?>"></td>
							</tr>
							<tr>
								<td id="d2">Educational Qualification</td>
								<td><input type="text" id="t16" name="fexd" value="<?php echo strtoupper($fexd);?>"></td>
								<td><input type="text" id="t17" name="mexd" value="<?php echo strtoupper($mexd);?>"></td>
								<td><input type="text" id="t18" name="gexd" value="<?php echo strtoupper($gexd);?>"></td>
							</tr>
							<tr><td id="d3">Occupation</td>
							<td><input type="text" id="t19" name="foccup" value="<?php echo strtoupper($foccup);?>"></td>
							<td><input type="text" id="t20" name="moccup" value="<?php echo strtoupper($moccup);?>"></td>
							<td><input type="text" id="t21" name="goccup" value="<?php echo strtoupper($goccup);?>"></td>
							</tr>
							<tr><td id="d4">Annual Income</td>
							<td><input type="text" id="t22" name="fincome" value="<?php echo strtoupper($fincome);?>" required></td>
							<td><input type="text" id="t23" name="mincome" value="<?php echo strtoupper($mincome);?>"></td>
							<td><input type="text" id="t24" name="gincome" value="<?php echo strtoupper($gincome);?>"></td>
							</tr>
							<tr><td id="d5">Contact No.</td>
							<td><input type="text" id="t25" name="fmob" value="<?php echo strtoupper($fmob);?>" required></td>
							<td><input type="text" id="t26" name="mmob" value="<?php echo strtoupper($mmob);?>"></td>
							<td><input type="text" id="t27" name="gmob" value="<?php echo strtoupper($gmob);?>"></td>
							</tr>
							<tr><td id="d6">E-mail</td>
							<td><input type="email" id="t28" name="femail" value="<?php echo $femail;?>" required></td>
							<td><input type="email" id="t29" name="memail" value="<?php echo $memail;?>"></td>
							<td><input type="email" id="t30" name="gemail" value="<?php echo $gemail;?>"></td>
							</tr>
							<tr><td id="d7">Address of Employment/<br>Business & Office Contact Nos.</td>
							<td><textarea id="t31" name="fadd" rows="10" cols="25" value=" "><?php echo strtoupper($fadd);?></textarea></td>
							<td><textarea id="t32" name="madd" rows="10" cols="25" value=" "><?php echo strtoupper($madd);?></textarea></td>
							<td><textarea id="t33" name="gadd" rows="10" cols="25" value=" "><?php echo strtoupper($gadd);?></textarea></td>
							</tr>
							<tr>
							<td align="right"><img src="../img/whatsapp.png" width="40" height="40"></td>
							<td><input type="text" id="t28" name="wapp" value="<?php echo strtoupper($wapp);?>"></td>
						</tr>
					</table><br><br>
					<b>Upload Images</b>
					<table id="img">
					<br><tr><td>  <img src="<?php echo $sphoto?>" width="120" height="120" /> <br>
					<input type="file" name="sphoto" id="t35" value=" "><br>
				Student</td>
				<td> <img src="<?php echo $fphoto?>" width="120" height="120" /> <br> <input type="file" name="fphoto" id="t35" value=" "><br>
				Father</td>
				<td> <img src="<?php echo $mphoto?>" width="120" height="120" /><br> <input type="file" name="mphoto" id="t35" value=" "><br>
				Mother</td>
				
				</tr>
				</table>
					
				</td>
				
				</tr>
						<tr><td align="right"> <img src="<?php echo $sign?>" width="120" height="120" /><br> <input type="file" name="sign" id="t35" value=" "><br>
				Sign</td></tr>
							</table>
							<br><br><b><input type="submit" value="Submit" id="sub" onClick="camera/index.php"><br><br>
							
							</b>
							
						</font>
			</center>
</form></div>

<?php
   $name=$dob=$rlg=$class=$sec_lang=$nat=$lang1=$lang2=$lang3=$lang4=$lang5=$sp1=$sp2=$sp3=$sp4=$sp5=$w1=$w2=$w3=$w4=$w5=$rno="";
   $re1=$re2=$re3=$re4=$re5=$aoh1=$aoh2=$aoh3=$gname=$gexd=$goccup=$gincome=$gmob=$gemail=$gadd=$wapp=""; 
   $Gender="";
   $pass="";
   //$sphoto=$fphoto=$mphoto=$rno="";
   
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
		
	if(!empty($_POST["pass"]))
	$pass=$_POST["pass"];
	
	$ay="2017-2018";
	$rno=$_POST['rc'];
    $name = $_POST['nos'];
	$dob=$_POST['dob'];
	$rlg=$_POST['rlg'];
    $class=$_POST['cls1'];
    $sec_lang=$_POST['seclang'];
      $Gender=$_POST['gender'];
    $nat=$_POST['ntl'];
    $mt=$_POST['mt'];
    $Caste=$_POST['caste'];
    $com=$_POST['com'];
    $Caste="$Caste-".$com;
    $Resadd=$_POST['res_add'];
    $mailadd=$_POST['mail_add'];
	
	if(!empty($_POST['lk1'])){
    $lang1=$_POST['lk1'];
	 $re1=$_POST['read1'];
	  $sp1=$_POST['speak1'];
	   $w1=$_POST['write1'];
	   }
	   if(!empty($_POST['lk2'])){
    $lang2=$_POST['lk2'];
	  $sp2=$_POST['speak2'];
	 $re2=$_POST['read2'];
	    $w2=$_POST['write2'];
	 }
	 if(!empty($_POST['lk3'])){
    $lang3=$_POST['lk3'];
	 $sp3=$_POST['speak3'];
	   $re3=$_POST['read3']; 
	   $w3=$_POST['write3'];
	   
	   }
	   if(!empty($_POST['lk4'])){
    $lang4=$_POST['lk4'];
	  $sp4=$_POST['speak4'];
	   $re4=$_POST['read4'];
	    $w4=$_POST['write4'];
	   
	   }
	   if(!empty($_POST['lk5'])){
    $lang5=$_POST['lk5']; 
    $sp5=$_POST['speak5'];   
    $re5=$_POST['read5'];
	 $w5=$_POST['write5'];
	}
   
 if(!empty($_POST['aohealthcare1'])) 
      $aoh1=$_POST['aohealthcare1'];
	  
	   if(!empty($_POST['aohealthcare2']))
      $aoh2=$_POST['aohealthcare2'];
	  
	   if(!empty($_POST['aohealthcare3']))
      $aoh3=$_POST['aohealthcare3'];
	  
      $fname=$_POST['fname'];
      $mname=$_POST['mname'];
	  if(!empty($_POST['gname']))
      $gname=$_POST['gname'];
	  
      $fexd=$_POST['fexd'];
      $mexd=$_POST['mexd'];
	   
	   if(!empty($_POST['gexd']))
      $gexd=$_POST['gexd'];
	  else $gexd="nil";
	  
      $foccup=$_POST['foccup'];
	  $moccup=$_POST['moccup'];
	  
	   if(!empty($_POST['goccup']))
	  $goccup=$_POST['goccup'];
	  else 
	  $goccup="nil";
	  
	  $fincome=$_POST['fincome'];
	  
	  if(!empty($_POST['gincome']))
	  $gincome=$_POST['gincome'];
	  else 
	  $gincome="nil";
	  
	  $mincome=$_POST['mincome'];
	  $fmob=$_POST['fmob'];
	  $mmob=$_POST['mmob'];
	  
	  if(!empty($_POST['gmob']))
	  $gmob=$_POST['gmob'];
	  else 
	  $gmob="nil";
	  
	  $femail=$_POST['femail'];
	  if(!empty($_POST['memail']))
	  $memail=$_POST['memail'];
	  else 
	  $memail="nil";
	  
	   if(!empty($_POST['gemail']))
	  $gemail=$_POST['gemail'];
	  else
	  $gemail="nil";
	  
	  $fadd=$_POST['fadd'];
	   if(!empty($_POST['gadd']))
	  $gadd=$_POST['gadd'];
	  else 
	  $gadd="nil";
	  $madd=$_POST['madd'];
	  if(!empty($_POST['wapp']))
	  $wapp=$_POST['wapp'];
	  else
	  $wapp="nil";

$con=@mysqli_connect("localhost","root","","#####");
if($con){
echo "Connected";
}
else
echo "not conected";

$stud="update student set date='$date',ayear='$ay',coa='$class',slang='$sec_lang',sname='$name',num='$fmob',gen='$Gender',dob='$dob',nat='$nat',reli='$rlg',mtoung='$mt',caste='$Caste',radd='$Resadd',madd='$mailadd',pass='$pass',rc='$rno' where apno='$id'";
$res=mysqli_query($con,$stud);
if($res){
echo "<br>updated";
}
else 
echo "<br> not updated";


//$id="500";
mkdir("images/".$id);

	if(!empty($_FILES["sphoto"])){
	
//	$sphoto=$_POST["sphoto"];

$target_dir = "images/$id/";
$target_file = $target_dir . basename($_FILES["sphoto"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["sphoto"]["tmp_name"]);
    if($check !== false) {
   //     //echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
     //   echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    //echo "Sorry, file already exists.";
    $uploadOk = 1;
}
// Check file size
if ($_FILES["sphoto"]["size"] > 500000000) {
   // echo "Sorry, your file is too large.";
    $uploadOk = 1;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    //echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    //echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["sphoto"]["tmp_name"], $target_file)) {
        //echo "The file ". basename( $_FILES["sphoto"]["name"]). " has been uploaded.";
		$sphoto="images/$id/" . basename($_FILES["sphoto"]["name"]);
		$str="update student set sphoto='$sphoto' where apno='$id'";
		$res=mysqli_query($con,$str);
    } else {
      //  echo "Sorry, there was an error uploading your file.";
    }
	


	//echo "$sphoto";
}

	
	}
	
	if(!empty($_FILES["fphoto"])){
	//$fphoto=$_POST["fphoto"];
	//mkdir("camera/images/".$id);
$target_dir = "images/$id/";
$target_file = $target_dir . basename($_FILES["fphoto"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fphoto"]["tmp_name"]);
    if($check !== false) {
        //echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        //echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    //echo "Sorry, file already exists.";
    $uploadOk = 1;
}
// Check file size
if ($_FILES["fphoto"]["size"] > 500000000) {
    //echo "Sorry, your file is too large.";
    $uploadOk = 1;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    //echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    //echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fphoto"]["tmp_name"], $target_file)) {
      //  echo "The file ". basename( $_FILES["fphoto"]["name"]). " has been uploaded.";
		$fphoto="images/$id/" . basename($_FILES["fphoto"]["name"]);
		echo "$fphoto";
    } else {
        //echo "Sorry, there was an error uploading your file.";
    }
}

	
	}
	
	if(!empty($_FILES["mphoto"])){
	//$mphoto=$_POST["mphoto"];
	//mkdir("camera/images/".$id);
$target_dir = "images/$id/";
$target_file = $target_dir . basename($_FILES["mphoto"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["mphoto"]["tmp_name"]);
    if($check !== false) {
        //echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        //echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    //echo "Sorry, file already exists.";
    $uploadOk = 1;
}
// Check file size
if ($_FILES["mphoto"]["size"] > 500000000) {
    //echo "Sorry, your file is too large.";
    $uploadOk = 1;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    //echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
   // echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["mphoto"]["tmp_name"], $target_file)) {
     //   echo "The file ". basename( $_FILES["mphoto"]["name"]). " has been uploaded.";
		$mphoto="images/$id/" . basename($_FILES["mphoto"]["name"]);
		echo "$mphoto";
    } else {
       // echo "Sorry, there was an error uploading your file.";
    }
}

}


if(!empty($_FILES["sign"])){
	//$mphoto=$_POST["mphoto"];
	//mkdir("camera/images/".$id);
$target_dir = "images/$id/";
$target_file = $target_dir . basename($_FILES["sign"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["sign"]["tmp_name"]);
    if($check !== false) {
        //echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        //echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    //echo "Sorry, file already exists.";
    $uploadOk = 1;
}
// Check file size
if ($_FILES["sign"]["size"] > 500000000) {
    //echo "Sorry, your file is too large.";
    $uploadOk = 1;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    //echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
   // echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["sign"]["tmp_name"], $target_file)) {
     //   echo "The file ". basename( $_FILES["mphoto"]["name"]). " has been uploaded.";
		$sign="images/$id/". basename($_FILES["sign"]["name"]);
		echo "$sign";
    } else {
       // echo "Sorry, there was an error uploading your file.";
    }
}

}


$lang="update stlang set lk1='$lang1',s1='$sp1',r1='$re1',w1='$w1',lk2='$lang2',s2='$sp2',r2='$re2',w2='$w2',lk3='$lang3',s3='$sp3',r3='$re3',w3='$w3',lk4='$lang4',s4='$sp4',r4='$re4',w4='$w4',lk5='$lang5',s5='$sp5',r5='$re5',w5='$w5',medi1=' $aoh1',medi2='$aoh2',medi3='$aoh3' where apno='$id'";
$res=mysqli_query($con,$lang);
if($res){
echo "<br>updated";
}
else 
echo "<br> not updated";
$prnt="update sparent set fname='$fname',fquali='$fexd',focc='$foccup',finc='$fincome',fmno='$fmob',femail='$femail',foffadd='$fadd',fphoto='$fphoto',mname='$mname',mquali='$mexd',mocc='$moccup',minc='$mincome',mmno='$mmob',memail='$memail',moffadd='$madd',mphoto='$mphoto',gname='$gname',gquali='$gexd',gocc='$goccup',ginc='$gincome',gmno='$gmob',gemail='$gemail',goffadd='$gadd',sign='$sign',whatsapp='$wapp' where apno='$id'";



$res=mysqli_query($con,$prnt);
if($res){
echo "<br>updated";
}
else 
echo "<br> not updated";
$_SESSION["apno"]=" ";

 echo "<script type='text/javascript'>
window.location.href = '../Index.php';
</script>";





}
}
else {
echo "Enter valid password";

}
?>

<b>Designed by Sasurie Info Tech</b>
</body>
</html>