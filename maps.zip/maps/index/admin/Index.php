<html>
<head>
<title>List</title>
 <link rel="shortcut icon" href="../admin/img/clg.jpg">
<style type="text/css">

}

</style>
<?php
    error_reporting(0);
   ob_start();
   session_start();
?>
</head>
<body style="width:auto; height:auto; background-image:url(img/3.png); background-size:100% auto;">
<div id="d1">
<br><br><br><br>

<table align="center">
<?php if($_SESSION["pass"]== "#####"){
?>
<tr><td style="background-color:#FFFF00"><img src="img/MAPSLogo.jpg" width="150" height="150"><img src="img/MAPSName.jpg" width="440" height="100"></td></tr>
<tr><td align="center" style=" background-color:#FFFFFF; opacity:0.7; border-radius:50px;"> <br><br><a href="maps.php"><b>NEW ENTRY</b></a></br></br></td></tr>
<tr><td align="center" style=" background-color:#FFFFFF; opacity:0.7; border-radius:50px;"> <br><br><a href="update.php"><b>UPDATE DATA</b></a></br></br></td></tr>
<tr><td align="center" style=" background-color:#FFFFFF; opacity:0.7; border-radius:50px;"><br><br> <a href="camera/v1.php"><b>VIEW</b></a></br></br></td></tr>
<?php $_SESSION["pass"]== "####"; }
else 
echo "enter valid password";


?>
<tr><td></br></br></td></tr>
</table>

</div>
</body>
</html>
