<html>
<head>
<title>List</title>
 <link rel="shortcut icon" href="../admin/img/clg.jpg">
<style type="text/css">

}

</style>
<?php
error_reporting(0);
   ob_start();
   session_start();
?>
</head>
<body style="width:auto; height:auto; background-image:url(img/36.jpg); background-size:100% auto;">
<div id="d1">
<br><br><br><br>

<table align="center">
<?php if($_SESSION["pass"]== "#####"){
?>
<tr><td style="background-color:#FFFF00"><img src="img/MAPSLogo.jpg" width="150" height="150"><img src="img/MAPSName.jpg" width="440" height="100"></td></tr>
<tr><td align="center"> <br /><br /><b>ENTER APPLICATION NUMBER</b></br></br></td></tr>
<tr><td align="center"> <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post"><input type="text" name="apn"  required/ style="box-shadow:2px 2px 10px #000; width:300px; height:30px; border-style:none;"></br></br></td></tr>
<tr><td align="center"><input type="submit" value="PROCEED"  style="background-color:#009900; border-radius:10px; border-style:none; width:80px; height:40px; box-shadow:2px 2px; 10px #fff;" /></form></br></br></td></tr>
<?php }
else 
echo "enter valid password";


   if ($_SERVER["REQUEST_METHOD"] == "POST") {
     $_SESSION["pass"]== "map123"; 
	 $ap=$_POST['apn'];
	 $_SESSION["apno"]=$ap;
	 
	  echo "<script type='text/javascript'>
window.location.href = 'camera/uppage.php';
</script>";
	 
  }
  
?>
<tr><td></br></br></td></tr>
</table>

</div>
</body>
</html>
