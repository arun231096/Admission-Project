<?php
   ob_start();
   session_start();
?>

<?
   // error_reporting(E_ALL);
   // ini_set("display_errors", 1);
?>

<html lang = "en">
   
   <head>
      <title>MAPS ADMIN</title>
      <link rel="shortcut icon" href="admin/img/clg.jpg">
      <link href = "css/bootstrap.min.css" rel = "stylesheet">
      
      <style>
         body {
            padding-top: 40px;
            padding-bottom: 40px;
            background-color: yellow;
            background-image: url("13.jpg");
           background-size: 100% auto;
         }
         
         .form-control{
         border: 2px solid green;
          //border-radius: 15px;
         }
         .form-control:hover{
         box-shadow: 2px 2px 15px green;
         }
         .form-signin {
            max-width: 330px;
            padding: 15px;
            margin: 0 auto;
            color: yellow;
         }
         
         .form-signin .form-signin-heading,
         .form-signin .checkbox {
            margin-bottom: 10px;
         }
         
         .form-signin .checkbox {
            font-weight: normal;
         }
         
         .form-signin  .form-control{
            position: relative;
            height: auto;
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
            padding: 10px;
            font-size: 16px;
         }
         
         .form-signin .form-control:focus {
            z-index: 2;
         }
         
         .form-signin input[type="email"] {
            margin-bottom: -1px;
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0;
            border-color:#017572;
         }
         
         .form-signin input[type="password"] {
            margin-bottom: 10px;
            border-top-left-radius: 0;
            border-top-right-radius: 0;
            border-color:#017572;
         }
         
         h2{
            text-align: center;
            color: green;
         }
         .btn{
         width:100px;
         height:40px;
         background-color:green;
         color:white;
         border-style:none;
         border-radius:10px;
        
         }
         .btn:hover{
          box-shadow: 2px 2px 15px white;
         }
      </style>
      
   </head>
	
   <body>
      
      
      <div class = "container form-signin">
         
         <?php
            $msg = '';
            
            if (isset($_POST['login']) && !empty($_POST['username']) 
               && !empty($_POST['password'])) {
				
               if ($_POST['username'] == '####' && 
                  $_POST['password'] == '###') {
                  $_SESSION['valid'] = true;
                  $_SESSION['timeout'] = time();
                  $_SESSION['username'] = '';
                   $_SESSION["pass"]="####";
                  echo 'You have entered valid use name and password';


            header("location: admin/Index.php");
         
               }else {
                  $msg = 'Wrong username or password';
                  echo "$msg";
               }
            }
            else 
               $mas="Put Valid Password";
            echo "$msg";
         ?>
      </div> <!-- /container -->
      
      <div class = "container">
     
         <form class = "form-signin" role = "form" 
            action = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']); 
            ?>" method = "post">
             <h2>Enter Username and Password</h2> 
			<table>
			<tr><td>
            <label><b>UserName</b>  </label></td><td><input type = "text" name = "username" class = "form-control"/><br /><br /></td></tr>
               <tr><td><label><b>Password</b></label></td><td><input type = "password" name = "password" class = "form-control" /></td></tr><br/><br />
            <tr><td></td>
               <td><button class = "btn btn-lg btn-primary btn-block" type = "submit" 
               name = "login">Login</button></td></tr></table>
         </form>
			
         
      </div> 
      
   </body>
</html>